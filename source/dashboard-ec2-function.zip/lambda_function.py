import json
import boto3
import csv
import os
import urllib3
from datetime import date, datetime, timedelta
from types import SimpleNamespace

url = "https://endoflife.date/api/" # external source of end of life! 
http = urllib3.PoolManager()

def lambda_handler(event, context):
    # TODO implement
    print("Gathering Data from EC2 AMI")
    
    ec2 = boto3.client("ec2")
    s3 = boto3.client('s3')
    
    instances = []
    ec2_response = ec2.describe_instances()
    if(len(ec2_response['Reservations']) != 0):
        for reservation in ec2_response['Reservations']: # get ec2 values from ec2 itself
            for instance in reservation['Instances']:
                instance_data = {}
                try:
                    instance_data['Name'] = instance['Tags'][0]['Value']
                    print(instance['Tags'][0]['Value'])
                except:
                    print("Unnamed Instance")
                    instance_data['Name'] = "Unnamed Instance"
                instance_data['ImageId'] = instance['ImageId']
                instance_data['InstanceId'] = instance['InstanceId']
                instance_data['InstanceType'] = instance['InstanceType']
                instance_data['LaunchTime'] = instance['LaunchTime']
                instance_data['AvailabilityZone'] = instance['Placement']['AvailabilityZone']
                instance_data['Platform'] = instance['PlatformDetails']
                print(instance['ImageId'])
                print(instance['InstanceId'])
                print(instance['InstanceType'])
                print(instance['LaunchTime'])
                print(instance['Placement']['AvailabilityZone'])
                print(instance['PlatformDetails'])
                print("\n")
                #get the days since opened
                today = datetime.today().strftime('%Y-%m-%d')
                instance_data['LaunchTime'] = instance_data['LaunchTime'].strftime('%Y-%m-%d')
                today_date = datetime.strptime(today,'%Y-%m-%d' )
                instance_date = datetime.strptime(instance_data['LaunchTime'],'%Y-%m-%d' ) 
                print(instance_date - today_date) 
                timedelta = today_date - instance_date # returns time delta obj
            
                instance_data['days_old'] = timedelta.days
                print(type(timedelta.days))
                instances.append(instance_data)
    else:     # set defaults if client has no ec2 instances       
        instance_data = {}
        instance_data['Name'] = "None"
        instance_data['ImageId'] = "None"
        instance_data['InstanceId'] = "None"
        instance_data['InstanceType'] = "None"
        instance_data['LaunchTime'] = "None"
        instance_data['AvailabilityZone'] = "None"
        instance_data['Platform'] = "None"
        instance_data['LaunchTime'] = "None"
        instance_data['days_old'] = 0
        instances.append(instance_data)

    bucket = os.environ['BUCKET_NAME'] # s3 bucket for zip
    key = 'eolDashboardBucketAWS::EC2::Instance.csv' # filename
    
    # print(instance_data)
    
    with open('/tmp/test.csv','a+') as dataFile:
        dataFile.truncate(0)
        writer = csv.writer(dataFile)
        writer.writerow(instance_data.keys())
        for instance in instances: 
            writer.writerow(instance.values())
            print(instance)


    with open('/tmp/test.csv') as dataFile: # do i need to reopen?
        dataString = dataFile.read()
        s3.put_object(Body=dataString, Bucket=bucket, Key=key)
        dataFile.close()
    

    return{
        'statusCode': 200,
        'body': json.dumps("Hey, something worked!"),
        # 'instances' : json.dumps(ec2_response['Reservations'][1], default=str)
    }

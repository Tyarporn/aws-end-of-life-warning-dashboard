import json
import boto3
import csv
import os
import urllib3
from datetime import date, datetime, timedelta
from types import SimpleNamespace
from crhelper import CfnResource

RDSclient = boto3.client('rds')
client = boto3.client('config')
ec2 = boto3.client("ec2")
s3 = boto3.client('s3')
helper = CfnResource()
url = "https://endoflife.date/api/" # external source of end of life! 
http = urllib3.PoolManager()


def lambda_handler(event, context):
    helper(event, context)

    
@helper.create
@helper.update
def buffer_function(event, context):
    ec2_retrieval(event,context)
    lambda_retrieval(event,context)
    rds_retrieval(event,context)
    
    
def getRuntimeLang(runtime):
    # instanceData['runtime'] = runtime
    lang = runtime.rstrip('0123456789.x ')
    version = runtime[len(lang):]
   
    ver_index =  len(runtime)
    
    for i in range(len(runtime)): 
        if(runtime[i] in "0123456789."):
            ver_index = i
            break
        
    print(runtime[:ver_index], runtime[ver_index:])
        
    return (runtime[:ver_index], runtime[ver_index:])
    
def compareRuntime(runtime, lang):
    # this list comes from https://github.com/boto/botocore/blob/develop/botocore/data/lambda/2015-03-31/service-2.json
    # please update as needed
    runtime_list = {
        'nodejs': ["nodejs","nodejs4.3","nodejs4.3-edge", "nodejs6.10","nodejs8.10","nodejs10.x","nodejs12.x","nodejs14.x","nodejs16.x"],
        'java':  ["java8","java8.al2","java11"],
        'python':["python2.7","python3.6","python3.7","python3.8","python3.9"],
        'dotnetcore':["dotnetcore1.0","dotnetcore2.0","dotnetcore2.1","dotnetcore3.1"],
        'dotnet':["dotnet6"],
        'go' : ["go1.x"],
        'ruby' : ["ruby2.5","ruby2.7"],
        'provided' :["provided","provided.al2"] 
    }
    diff = 0
    try:
        index = runtime_list[lang].index(runtime)
        diff = abs(index - (len(runtime_list[lang]) - 1))
    except:
        return -1
        
    return diff
    
def find_eol_url(runtime):
    split = getRuntimeLang(runtime)
    lang = split[0]
    version_raw = split[1]
    version = ""
    if(lang == "nodejs"):
        version = version_raw.rstrip('.x')
    elif(lang == "dotnet"):
        # lang = ""
        version = version_raw + ".0"
    elif(lang == "dotnetcore"):
        lang = "dotnet"
        version = "core " + version_raw
    elif(lang == "java"):
        version = version_raw.rstrip('.al2')
    else:
        version = version_raw
        
    req_url = lang+ "/" + version + ".json"
    try:
        res_byte = http.request('GET', url + req_url)
        res = json.loads(res_byte.data)
        res_eol = res['eol']
    except:
        res_eol = "N/A"
    
    return res_eol

def retrieveOfficialEoL(engine, engineVersion):
    if engine == 'mysql':
        cycle = engineVersion[:engineVersion.rfind('.')]
        mysql_req = http.request('GET', url + 'mysql/'+cycle+'.json')
        mysql_res = json.loads(mysql_req.data)
        return mysql_res['eol']
        
    elif engine == 'postgres':
        cycle = engineVersion.split('.')
        if(int(cycle[0])>9):
            postgresql_req = http.request('GET', url + 'postgresql/'+cycle[0]+'.json')
            postgresql_res = json.loads(postgresql_req.data)
        else:
            postgresql_req = http.request('GET', url + 'postgresql/'+cycle[0]+'.'+cycle[1]+'.json')
            postgresql_res = json.loads(postgresql_req.data)
        return postgresql_res['eol']
    elif engine == "sqlserver-ex" or engine == "sqlserver-se" or engine == "sqlserver-ee" or engine == "sqlserver-web":
        mssqlserver_req = http.request('GET', url + 'mssqlserver.json')
        mssqlserver_res = json.loads(mssqlserver_req.data)
        cycle = engineVersion[:engineVersion.find('.')]
        for engineCycle in mssqlserver_res:
            latest = engineCycle['latest']
            if cycle == latest[:latest.find('.')]:
                return engineCycle['eol']
        return "No Data Available"
    elif engine == 'mariadb':
        cycle = engineVersion[:engineVersion.rfind('.')]
        mariadb_req = http.request('GET', url + 'mariadb/'+cycle+'.json')
        mariadb_res = json.loads(mariadb_req.data)
        return mariadb_res['eol']
    else:
        return "No Data Available"
    
    
    
def getLatestVersion(eng_ver_response, engineVersion, engType):
    """
    Retrieve the latest version for db engine
    @param eng_ver_response: -> (dict) RDSclient.describe_db_engine_versions(Engine=Engine)
    @param str engineVersion: -> (str) current version
    @return (str) the latest version of engine
    """
    print('Inside get Engine Version')
    engineVersions = []
    LatestVersion = ''
    for engine in eng_ver_response['DBEngineVersions']:
        engineVersions.append(engine['EngineVersion'])
    engineVersions.sort()
    
    majorVersions = []
    currMajVer = 0
    if(engType == "mysql"  or engType == "postgres" or engType == "aurora-postgresql" or engType == "oracle-ee" or engType == "oracle-ee-cdb" or engType == "oracle-se2" or engType == "oracle-se2-cdb"):
        # TODO
        for ver in engineVersions:
            digit = ver.split('.')[0]
            if digit not in majorVersions:
                majorVersions.append(digit)
        currMajVer = engineVersion.split('.')[0]
        verGap = majorVersions.index(currMajVer)+1    #VERGAP IS ACTUALLY THE INVERSE OF VERSION GAPS I.E. 6 TOTAL MAJOR VERSIONS & 2 VERSIONS BEHIND MAKES VERGAP=4
    elif(engType == "mariadb" or engType == "sqlserver-ex" or engType == "sqlserver-se" or engType == "sqlserver-ee" or engType == "sqlserver-web"):
        for ver in engineVersions:
            digits = ver.split('.', 3)
            majVer = ver[:len(ver)-len(digits[-1])-1]
            if majVer not in majorVersions:
                majorVersions.append(majVer)
        digits2 = engineVersion.split('.', 3)
        currMajVer = engineVersion[:len(engineVersion)-len(digits2[-1])-1]
        verGap = majorVersions.index(currMajVer)+1
    elif(engType == "aurora-mysql"):
        # TODO
        for ver in engineVersions:
            digit = ver.split('.')[3]
            if digit not in majorVersions:
                majorVersions.append(digit)
        currMajVer = engineVersion.split('.')[3]
        verGap = majorVersions.index(currMajVer)+1    #VERGAP IS ACTUALLY THE INVERSE OF VERSION GAPS I.E. 6 TOTAL MAJOR VERSIONS & 2 VERSIONS BEHIND MAKES VERGAP=4
    else:
        verGap = 0

    LatestVersion = engineVersions[-1]
    return [LatestVersion, verGap, len(majorVersions)]
    
def lambda_retrieval(event, context):
    # TODO implement

    print("Gathering Data from Lambda ")
    
    client = boto3.client('config') #  pull data from config
    s3 = boto3.client('s3')
    
    resource = "AWS::Lambda::Function"
    resourceList = {}

    response = client.list_discovered_resources(resourceType=resource)
        # print(response)
        
    for resourceName in response['resourceIdentifiers']:
        resourceID = resourceName['resourceId']
        resourceType = resourceName['resourceType']
        ResResponse = client.batch_get_resource_config(
        resourceKeys=[
            {
                'resourceType': resourceType,
                'resourceId': resourceID
            },
        ]
        )
            # print("baseconfig ", ResResponse['baseConfigurationItems'])
        
        for baseConfigurationItems in ResResponse['baseConfigurationItems']:
            instanceData = {}
            if 'configuration' in baseConfigurationItems:
                configurationData = json.loads(baseConfigurationItems['configuration'])
                print(configurationData)
                if 'functionName' in configurationData:
                    instanceData['functionName'] = configurationData['functionName']
                if 'functionArn' in configurationData:
                    instanceData['functionArn'] = configurationData['functionArn']
                if 'runtime' in configurationData:
                    runtime = configurationData['runtime']
                    # print(runtime)
                    runtime_lang = getRuntimeLang(runtime)
                    instanceData['runtimeInfo'] = runtime
                    instanceData['runtimesBehind'] = compareRuntime(runtime, runtime_lang[0])
                    
                    # get the days until end of life date
                    if(runtime_lang[0] == 'go' or runtime[0] == 'provided'): # go only puts back "go 1.x" so we can't use this. update later?
                        instanceData['eolDate'] = "unsupported"
                        instanceData['days_until_eol'] = 0
                    else:
                        instanceData['eolDate'] = find_eol_url(runtime)
                        today = datetime.today().strftime('%Y-%m-%d')
                        today_date = datetime.strptime(today,'%Y-%m-%d')
                        eol_date = datetime.strptime(instanceData['eolDate'],'%Y-%m-%d') 
                        timedelta = eol_date - today_date
                        instanceData['days_until_eol'] = timedelta.days
                    print(instanceData['eolDate'])
                    print(instanceData['runtimesBehind'])
        try:
            resourceList[instanceData['functionName']] = instanceData
        except:
            print("failed")
    if len(resourceList) == 0:   
        instanceData = {}
        instanceData['functionName'] = "None"
        instanceData['functionArn'] = "None"
        instanceData['runtimeInfo'] = "None"
        instanceData['runtimesBehind'] = 0
        instanceData['eolDate'] = "None"
        instanceData['days_until_eol'] = 0
        resourceList[instanceData['functionName']] = instanceData
        # pass
        
        
    bucket = os.environ['BUCKET_NAME'] # s3 bucket for zip
    key = 'eolDashboardBucket' + resource + '.csv' # file name
    
    with open('/tmp/test.csv','a+') as dataFile:
        dataFile.truncate(0)
        writer = csv.writer(dataFile)
        writer.writerow(resourceList[list(resourceList.keys())[0]])
        for instance in resourceList: 
          writer.writerow(list(resourceList[instance].values()))


    with open('/tmp/test.csv') as dataFile: # do i need to reopen?
        dataString = dataFile.read()
        s3.put_object(Body=dataString, Bucket=bucket, Key=key)
        dataFile.close()

def rds_retrieval(event, context):
    """
    Query Config and put csv file of RDS instance into S3
    @param event -> (dict) idk what this is
    @param context -> (awslambdaric.lambda_context.LambdaContext) idk what this is either
    @return completion status
    """
    resource = "AWS::RDS::DBInstance" # just for RDS for now. Update with binu's list later?
    
    
    rdsInstances = {}
    
    resourcesCount = 0
    ResourceData = json.dumps({})
    response = client.list_discovered_resources(
    resourceType=resource)
    
    for resourceName in response['resourceIdentifiers']:
        instanceData = {}
        resourceID = resourceName['resourceId']

        ResResponse = client.batch_get_resource_config(
        resourceKeys=[
            {
                'resourceType': resource,
                'resourceId': resourceID
            },
        ]
        )
        
        for baseConfigurationItems in ResResponse['baseConfigurationItems']:
            
            for cat in baseConfigurationItems:
                if cat == 'awsRegion':
                    if baseConfigurationItems[cat] == "us-east-1":
                        instanceData['zipLocation'] = 20009
                    elif baseConfigurationItems[cat] == "us-east-2":
                        instanceData['zipLocation'] = 43537
                    elif baseConfigurationItems[cat] == "us-west-1":
                        instanceData['zipLocation'] = 94088
                    elif baseConfigurationItems[cat] == "us-west-2":
                        instanceData['zipLocation'] = 97035
                    else:
                        instanceData['zipLocation'] = 63005
                    instanceData[cat] = baseConfigurationItems[cat]
                elif cat != 'configuration':
                    try:
                        instanceData[cat] = baseConfigurationItems[cat]
                    except:
                        instanceData[cat] = "NOT FOUND"
            if 'configuration' in baseConfigurationItems:
                configurationData = json.loads(baseConfigurationItems['configuration'])
                if 'engine' in configurationData:
                    instanceData['engine'] = configurationData['engine']
                    if resource == 'AWS::RDS::DBInstance': # is this rds specific
                        eng_ver_response = RDSclient.describe_db_engine_versions(Engine=instanceData['engine'])
                if 'engineVersion' in configurationData:
                    instanceData['engineVersion'] = configurationData['engineVersion']
                    
                    versionInfo = getLatestVersion(eng_ver_response,instanceData['engineVersion'], instanceData['engine'])
                    instanceData['latestVersion'] = versionInfo[0]
                    instanceData['majVersionNumberStd'] = versionInfo[1]
                    instanceData['totalMajVersions'] = versionInfo[2]
                if 'licenseModel' in configurationData:
                    instanceData['licenseModel'] = configurationData['licenseModel']
                if 'storageType' in configurationData:
                    instanceData['storageType'] = configurationData['storageType']
                
        eolDate = str(retrieveOfficialEoL(instanceData['engine'], instanceData['engineVersion']))
        if eolDate != 'No Data Available':
            eolDateFormat = eolDate.split('/') #reformat to match AWS Config date conventions
            instanceData['eolDate'] = str(eolDateFormat[0])
        else:
            instanceData['eolDate'] = eolDate
        try:
            rdsInstances[instanceData['resourceName']] = instanceData
        except:
            print("Failed")
    
    if len(rdsInstances) == 0:
        placeholder = {}
        placeholder['version'] = 0
        placeholder['accountId'] = 0
        placeholder['configurationItemCaptureTime'] = ""
        placeholder['configurationItemStatus'] = ""
        placeholder['configurationStateId'] = 0
        placeholder['arn'] = ""
        placeholder['resourceType'] = ""
        placeholder['resourceId'] = ""
        placeholder['resourceName'] = ""
        placeholder['zipLocation'] = ""
        placeholder['awsRegion'] = ""
        placeholder['availabilityZone'] = ""
        placeholder['resourceCreationTime'] = ""
        placeholder['supplementaryConfiguration'] = ""
        placeholder['engine'] = ""
        placeholder['engineVersion'] = ""
        placeholder['latestVersion'] = ""
        placeholder['majVersionNumberStd'] = 0
        placeholder['totalMajVersions'] = 0
        placeholder['licenseModel'] = ""
        placeholder['storageType'] = ""
        placeholder['eolDate'] = ""
        rdsInstances['placeholder'] = placeholder

    # write to csv file
    bucket = os.environ['BUCKET_NAME']
    key = 'eolDashboardBucket' + resource + '.csv' # file name
    with open('/tmp/test.csv','a+') as dataFile:
        dataFile.truncate(0)
        writer = csv.writer(dataFile)
        writer.writerow(rdsInstances[list(rdsInstances.keys())[0]])
        for instance in rdsInstances: 
            writer.writerow(list(rdsInstances[instance].values()))
        dataFile.close()
    with open('/tmp/test.csv') as dataFile: # do i need to reopen?
        dataString = dataFile.read()
        s3.put_object(Body=dataString, Bucket=bucket, Key=key)
        dataFile.close()

    
def ec2_retrieval(event, context):
     # TODO implement
    print("Gathering Data from EC2 AMI")
    
    ec2 = boto3.client("ec2")
    s3 = boto3.client('s3')
    
    instances = []
    ec2_response = ec2.describe_instances()
    if(len(ec2_response['Reservations']) != 0):
        for reservation in ec2_response['Reservations']: # get ec2 values from ec2 itself
            for instance in reservation['Instances']:
                instance_data = {}
                try:
                    instance_data['Name'] = instance['Tags'][0]['Value']
                    print(instance['Tags'][0]['Value'])
                except:
                    print("Unnamed Instance")
                    instance_data['Name'] = "Unnamed Instance"
                instance_data['ImageId'] = instance['ImageId']
                instance_data['InstanceId'] = instance['InstanceId']
                instance_data['InstanceType'] = instance['InstanceType']
                instance_data['LaunchTime'] = instance['LaunchTime']
                instance_data['AvailabilityZone'] = instance['Placement']['AvailabilityZone']
                instance_data['Platform'] = instance['PlatformDetails']
                print(instance['ImageId'])
                print(instance['InstanceId'])
                print(instance['InstanceType'])
                print(instance['LaunchTime'])
                print(instance['Placement']['AvailabilityZone'])
                print(instance['PlatformDetails'])
                print("\n")
                #get the days since opened
                today = datetime.today().strftime('%Y-%m-%d')
                instance_data['LaunchTime'] = instance_data['LaunchTime'].strftime('%Y-%m-%d')
                today_date = datetime.strptime(today,'%Y-%m-%d' )
                instance_date = datetime.strptime(instance_data['LaunchTime'],'%Y-%m-%d' ) 
                print(instance_date - today_date) 
                timedelta = today_date - instance_date # returns time delta obj
            
                instance_data['days_old'] = timedelta.days
                print(type(timedelta.days))
                instances.append(instance_data)
    else:     # set defaults if client has no ec2 instances       
        instance_data = {}
        instance_data['Name'] = "None"
        instance_data['ImageId'] = "None"
        instance_data['InstanceId'] = "None"
        instance_data['InstanceType'] = "None"
        instance_data['LaunchTime'] = "None"
        instance_data['AvailabilityZone'] = "None"
        instance_data['Platform'] = "None"
        instance_data['LaunchTime'] = "None"
        instance_data['days_old'] = 0
        instances.append(instance_data)

    bucket = os.environ['BUCKET_NAME'] # s3 bucket for zip
    key = 'eolDashboardBucketAWS::EC2::Instance.csv' # filename
    
    # print(instance_data)
    
    with open('/tmp/test.csv','a+') as dataFile:
        dataFile.truncate(0)
        writer = csv.writer(dataFile)
        writer.writerow(instance_data.keys())
        for instance in instances: 
            writer.writerow(instance.values())
            print(instance)


    with open('/tmp/test.csv') as dataFile: # do i need to reopen?
        dataString = dataFile.read()
        s3.put_object(Body=dataString, Bucket=bucket, Key=key)
        dataFile.close()
    
@helper.delete
def no_op(_,__):
    pass






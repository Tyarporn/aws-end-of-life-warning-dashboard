import json
import boto3
import csv
import os
import urllib3
from types import SimpleNamespace

RDSclient = boto3.client('rds')
client = boto3.client('config')
s3 = boto3.client('s3')
url = "https://endoflife.date/api/"
http = urllib3.PoolManager()

def lambda_handler(event, context):
    return version_retrieval(event, context)

def retrieveOfficialEoL(engine, engineVersion):
    if engine == 'mysql':
        cycle = engineVersion[:engineVersion.rfind('.')]
        mysql_req = http.request('GET', url + 'mysql/'+cycle+'.json')
        mysql_res = json.loads(mysql_req.data)
        return mysql_res['eol']
        
    elif engine == 'postgres':
        cycle = engineVersion.split('.')
        if(int(cycle[0])>9):
            postgresql_req = http.request('GET', url + 'postgresql/'+cycle[0]+'.json')
            postgresql_res = json.loads(postgresql_req.data)
        else:
            postgresql_req = http.request('GET', url + 'postgresql/'+cycle[0]+'.'+cycle[1]+'.json')
            postgresql_res = json.loads(postgresql_req.data)
        return postgresql_res['eol']
    elif engine == "sqlserver-ex" or engine == "sqlserver-se" or engine == "sqlserver-ee" or engine == "sqlserver-web":
        mssqlserver_req = http.request('GET', url + 'mssqlserver.json')
        mssqlserver_res = json.loads(mssqlserver_req.data)
        cycle = engineVersion[:engineVersion.find('.')]
        for engineCycle in mssqlserver_res:
            latest = engineCycle['latest']
            if cycle == latest[:latest.find('.')]:
                return engineCycle['eol']
        return "No Data Available"
    elif engine == 'mariadb':
        cycle = engineVersion[:engineVersion.rfind('.')]
        mariadb_req = http.request('GET', url + 'mariadb/'+cycle+'.json')
        mariadb_res = json.loads(mariadb_req.data)
        return mariadb_res['eol']
    else:
        return "No Data Available"


def getLatestVersion(eng_ver_response, engineVersion, engType):
    """
    Retrieve the latest version for db engine
    @param eng_ver_response: -> (dict) RDSclient.describe_db_engine_versions(Engine=Engine)
    @param str engineVersion: -> (str) current version
    @return (str) the latest version of engine
    """
    engineVersions = []
    LatestVersion = ''
    for engine in eng_ver_response['DBEngineVersions']:
        engineVersions.append(engine['EngineVersion'])
    engineVersions.sort()
    
    majorVersions = []
    currMajVer = 0
    if(engType == "mysql"  or engType == "postgres" or engType == "aurora-postgresql" or engType == "oracle-ee" or engType == "oracle-ee-cdb" or engType == "oracle-se2" or engType == "oracle-se2-cdb"):
        for ver in engineVersions:
            digit = ver.split('.')[0]
            if digit not in majorVersions:
                majorVersions.append(digit)
        currMajVer = engineVersion.split('.')[0]
        verGap = majorVersions.index(currMajVer)+1    #VERGAP IS ACTUALLY THE INVERSE OF VERSION GAPS I.E. 6 TOTAL MAJOR VERSIONS & 2 VERSIONS BEHIND MAKES VERGAP=4
    elif(engType == "mariadb" or engType == "sqlserver-ex" or engType == "sqlserver-se" or engType == "sqlserver-ee" or engType == "sqlserver-web"):
        for ver in engineVersions:
            digits = ver.split('.', 3)
            majVer = ver[:len(ver)-len(digits[-1])-1]
            if majVer not in majorVersions:
                majorVersions.append(majVer)
        digits2 = engineVersion.split('.', 3)
        currMajVer = engineVersion[:len(engineVersion)-len(digits2[-1])-1]
        verGap = majorVersions.index(currMajVer)+1
    elif(engType == "aurora-mysql"):
        for ver in engineVersions:
            digit = ver.split('.')[3]
            if digit not in majorVersions:
                majorVersions.append(digit)
        currMajVer = engineVersion.split('.')[3]
        verGap = majorVersions.index(currMajVer)+1    #VERGAP IS ACTUALLY THE INVERSE OF VERSION GAPS I.E. 6 TOTAL MAJOR VERSIONS & 2 VERSIONS BEHIND MAKES VERGAP=4
    else:
        verGap = 0
    LatestVersion = engineVersions[-1]
    return [LatestVersion, verGap, len(majorVersions)]

def version_retrieval(event, context):
    """
    Query Config and put csv file of RDS instance into S3
    @param event -> (dict) idk what this is
    @param context -> (awslambdaric.lambda_context.LambdaContext) idk what this is either
    @return completion status
    """
    resource = "AWS::RDS::DBInstance" # just for RDS for now. Update with binu's list later?
    
    
    rdsInstances = {}
    
    resourcesCount = 0
    ResourceData = json.dumps({})
    response = client.list_discovered_resources(
    resourceType=resource)
    
    for resourceName in response['resourceIdentifiers']:
        instanceData = {}
        resourceID = resourceName['resourceId']

        ResResponse = client.batch_get_resource_config(
        resourceKeys=[
            {
                'resourceType': resource,
                'resourceId': resourceID
            },
        ]
        )
        
        for baseConfigurationItems in ResResponse['baseConfigurationItems']:
            
            for cat in baseConfigurationItems:
                if cat == 'awsRegion':
                    if baseConfigurationItems[cat] == "us-east-1":
                        instanceData['zipLocation'] = 20009
                    elif baseConfigurationItems[cat] == "us-east-2":
                        instanceData['zipLocation'] = 43537
                    elif baseConfigurationItems[cat] == "us-west-1":
                        instanceData['zipLocation'] = 94088
                    elif baseConfigurationItems[cat] == "us-west-2":
                        instanceData['zipLocation'] = 97035
                    else:
                        instanceData['zipLocation'] = 63005
                    instanceData[cat] = baseConfigurationItems[cat]
                elif cat != 'configuration':
                    try:
                        instanceData[cat] = baseConfigurationItems[cat]
                    except:
                        instanceData[cat] = "NOT FOUND"
            if 'configuration' in baseConfigurationItems:
                configurationData = json.loads(baseConfigurationItems['configuration'])
                if 'engine' in configurationData:
                    instanceData['engine'] = configurationData['engine']
                    if resource == 'AWS::RDS::DBInstance': # is this rds specific
                        eng_ver_response = RDSclient.describe_db_engine_versions(Engine=instanceData['engine'])
                if 'engineVersion' in configurationData:
                    instanceData['engineVersion'] = configurationData['engineVersion']
                    
                    versionInfo = getLatestVersion(eng_ver_response,instanceData['engineVersion'], instanceData['engine'])
                    instanceData['latestVersion'] = versionInfo[0]
                    instanceData['majVersionNumberStd'] = versionInfo[1]
                    instanceData['totalMajVersions'] = versionInfo[2]
                if 'licenseModel' in configurationData:
                    instanceData['licenseModel'] = configurationData['licenseModel']
                if 'storageType' in configurationData:
                    instanceData['storageType'] = configurationData['storageType']
                
        eolDate = str(retrieveOfficialEoL(instanceData['engine'], instanceData['engineVersion']))
        if eolDate != 'No Data Available':
            eolDateFormat = eolDate.split('/') #reformat to match AWS Config date conventions
            instanceData['eolDate'] = str(eolDateFormat[0])
        else:
            instanceData['eolDate'] = eolDate
        try:
            rdsInstances[instanceData['resourceName']] = instanceData
        except:
            print("Failed")
    
    if len(rdsInstances) == 0:
        placeholder = {}
        placeholder['version'] = 0
        placeholder['accountId'] = 0
        placeholder['configurationItemCaptureTime'] = ""
        placeholder['configurationItemStatus'] = ""
        placeholder['configurationStateId'] = 0
        placeholder['arn'] = ""
        placeholder['resourceType'] = ""
        placeholder['resourceId'] = ""
        placeholder['resourceName'] = ""
        placeholder['zipLocation'] = ""
        placeholder['awsRegion'] = ""
        placeholder['availabilityZone'] = ""
        placeholder['resourceCreationTime'] = ""
        placeholder['supplementaryConfiguration'] = ""
        placeholder['engine'] = ""
        placeholder['engineVersion'] = ""
        placeholder['latestVersion'] = ""
        placeholder['majVersionNumberStd'] = 0
        placeholder['totalMajVersions'] = 0
        placeholder['licenseModel'] = ""
        placeholder['storageType'] = ""
        placeholder['eolDate'] = ""
        rdsInstances['placeholder'] = placeholder

    # write to csv file
    bucket = os.environ['BUCKET_NAME']
    key = 'eolDashboardBucket' + resource + '.csv' # file name
    with open('/tmp/test.csv','a+') as dataFile:
        dataFile.truncate(0)
        writer = csv.writer(dataFile)
        writer.writerow(rdsInstances[list(rdsInstances.keys())[0]])
        for instance in rdsInstances: 
            writer.writerow(list(rdsInstances[instance].values()))
        dataFile.close()
    with open('/tmp/test.csv') as dataFile: # do i need to reopen?
        dataString = dataFile.read()
        s3.put_object(Body=dataString, Bucket=bucket, Key=key)
        dataFile.close()
    

    return{
        'statusCode': 200,
        'body': json.dumps('Successful code completion!')
    }

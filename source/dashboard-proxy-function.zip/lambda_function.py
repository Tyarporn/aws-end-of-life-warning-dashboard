import json
import boto3
# import datetime

def lambda_handler(event, context):
    # TODO implement
    client = boto3.client('events')
    response = client.put_events(
        Entries=[
            {
            #   'Time': datetime(2015, 1, 1),
                'Source': 'string',
                'Resources': [

                    ''
                ],
                'DetailType': 'string',
                'Detail': json.dumps({'':''}),
                # 'Detail': "",
                'EventBusName': 'eol-event-bus',
                'TraceHeader': 'string'
            },
        ],
        # EndpointId='string'
    )
    print(response)
    return { 
        'statusCode': 200,
        'body': json.dumps("Proxy executed"),
        'response': response
    }

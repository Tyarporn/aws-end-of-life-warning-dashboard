import json
import boto3
import csv
import os
import urllib3
from datetime import date, datetime
from types import SimpleNamespace
url = "https://endoflife.date/api/"
http = urllib3.PoolManager()
def getRuntimeLang(runtime):
    # instanceData['runtime'] = runtime
    lang = runtime.rstrip('0123456789.x ')
    version = runtime[len(lang):]
   
    ver_index =  len(runtime)
    
    for i in range(len(runtime)): 
        if(runtime[i] in "0123456789."):
            ver_index = i
            break
        
    print(runtime[:ver_index], runtime[ver_index:])
        
    return (runtime[:ver_index], runtime[ver_index:])
    
def compareRuntime(runtime, lang):
    # this list comes from https://github.com/boto/botocore/blob/develop/botocore/data/lambda/2015-03-31/service-2.json
    # please update as needed
    runtime_list = {
        'nodejs': ["nodejs","nodejs4.3","nodejs4.3-edge", "nodejs6.10","nodejs8.10","nodejs10.x","nodejs12.x","nodejs14.x","nodejs16.x"],
        'java':  ["java8","java8.al2","java11"],
        'python':["python2.7","python3.6","python3.7","python3.8","python3.9"],
        'dotnetcore':["dotnetcore1.0","dotnetcore2.0","dotnetcore2.1","dotnetcore3.1"],
        'dotnet':["dotnet6"],
        'go' : ["go1.x"],
        'ruby' : ["ruby2.5","ruby2.7"],
        'provided' :["provided","provided.al2"] 
    }
    diff = 0
    try:
        index = runtime_list[lang].index(runtime)
        diff = abs(index - (len(runtime_list[lang]) - 1))
    except:
        return -1
        
    return diff
    
    
def find_eol_url(runtime):
    split = getRuntimeLang(runtime)
    lang = split[0]
    version_raw = split[1]
    version = ""
    if(lang == "nodejs"):
        version = version_raw.rstrip('.x')
    elif(lang == "dotnet"):
        # lang = ""
        version = version_raw + ".0"
    elif(lang == "dotnetcore"):
        lang = "dotnet"
        version = "core " + version_raw
    elif(lang == "java"):
        version = version_raw.rstrip('.al2')
    else:
        version = version_raw
        
    req_url = lang+ "/" + version + ".json"
    try:
        res_byte = http.request('GET', url + req_url)
        res = json.loads(res_byte.data)
        res_eol = res['eol']
    except:
        res_eol = "1900-01-01"
    
    return res_eol
    
def lambda_handler(event, context):
    # TODO implement
    print("Gathering Data from Lambda ")
    
    lambda_client = boto3.client('lambda') #  pull data from config
    s3 = boto3.client('s3')
    
    function_response = lambda_client.list_functions()
    functions = function_response["Functions"]
    
    lambda_functions = {}
    if len(functions) !=0:
        for function in functions:
            instanceData = {}
            instanceData['FunctionName'] = function['FunctionName']
            instanceData['FunctionArn'] = function['FunctionArn']
            
            runtime = function["Runtime"]
            instanceData['Runtime'] = runtime
        
            runtime_lang = getRuntimeLang(runtime)
                             
            instanceData['RuntimesBehind'] = compareRuntime(runtime, runtime_lang[0])
        
            if(runtime_lang[0] == 'go' or runtime[0] == 'provided'): # go only puts back "go 1.x" so we can't use this. update later?
                instanceData['eolDate'] = "1900-01-01"
                instanceData['days_until_eol'] = 0
            else:
                instanceData['eolDate'] = find_eol_url(runtime)
                today = datetime.today().strftime('%Y-%m-%d')
                today_date = datetime.strptime(today,'%Y-%m-%d')
                eol_date = datetime.strptime(instanceData['eolDate'],'%Y-%m-%d') 
                timedelta = eol_date - today_date
                instanceData['days_until_eol'] = timedelta.days
            print(instanceData)
            lambda_functions[instanceData['FunctionName']] = instanceData
    else:
        instanceData = {}
        instanceData['FunctionName'] = "None"
        instanceData['FunctionArn'] = "None"
        instanceData['Runtime'] = "None"
        instanceData['RuntimesBehind'] = 0
        instanceData['eolDate'] = "1900-01-01"
        instanceData['days_until_eol'] = 0
        lambda_functions[instanceData['FunctionName']] = instanceData
        
        
    bucket = os.environ['BUCKET_NAME'] # s3 bucket for zip
    # bucket = "eol-dashboard-data-bucket" # s3 bucket for testing
    key = 'eolDashboardBucketAWS::Lambda::Function.csv' # file name
    
    with open('/tmp/test.csv','a+') as dataFile:
        dataFile.truncate(0)
        writer = csv.writer(dataFile)
        writer.writerow(lambda_functions[list(lambda_functions.keys())[0]])
        for instance in lambda_functions: 
          writer.writerow(list(lambda_functions[instance].values()))
    with open('/tmp/test.csv') as dataFile: # do i need to reopen?
        dataString = dataFile.read()
        s3.put_object(Body=dataString, Bucket=bucket, Key=key)
        dataFile.close()
    
    
    return {
        'statusCode': 200,
        'body' : json.dumps("Hey, something worked!")
        
    }